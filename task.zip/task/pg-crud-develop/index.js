const express=require('express')
const bodyparser=require('body-parser')

const app=express()

const db=require('./query')

app.use(bodyparser.json())

app.use(bodyparser.urlencoded({extended:false}))
//Create users with name, email, mobile, password, address
app.post('/user',db.createUser)
//User login (If a user login multiple times in a day, we should restrict)
app.post('/login/:id',db.getUserById)
//pagination
app.get("/getalluserasc",db.getAllUsers)
//Delete a user with soft delete
app.put('/updateUser/:id',db.updateUser)

app.listen(3000,() => console.log('listening to the port 3000 ...'))