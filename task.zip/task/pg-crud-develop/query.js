const Pool=require('pg').Pool

const pool=new Pool({
    user: 'theiva',
    host: 'localhost',
    database: 'postgres',
    password: 'Admin',
    port:5432
})

const createUser = (request, response) => {
  const { name,email,mobile,password } = request.body

  pool.query('INSERT INTO users (name,email,mobile,password,userstatus) VALUES ($1, $2, $3,$4,$5)', [name,email,mobile,password], (error, results) => {
    if (error) {
      throw error
    }
    response.status(201).send(`User added with ID: ${name}`)
  })
}

const getUserById = (request, response) => {
  
  const id = request.params.name;
  const password = request.params.password
  
 console.log('id is '+id)
  pool.query('SELECT * FROM users WHERE name = $1', [id,password], (error, results) => {
    if (error) {
      throw error
    }
    response.status(200).json(results.rows)
  })
}
const updateUser= (request, response) =>
{
  const id = request.params.name;
  const {userstatus} = request.body
  console.log('id is '+id)

  pool.query('update users set userstatus where name=$1',[userstatus,id], (error,results)=>
  {
    if(error){
      throw error
    }
    response.status(200).send(`user modified with ${name}`)
  })
}
//pagination
const getAllUsers=(request,response) =>{

  pool.query("SELECT * FROM users ORDER BY 'name' ASC", (error,results)=>
  {
    if(error)
    throw error
    response.status(200).json(results.rows)
  }
  )
}


module.exports ={
createUser,
getUserById,
updateUser, getAllUsers

}



